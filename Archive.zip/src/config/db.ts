// DB connection placeholder
export const db = {};